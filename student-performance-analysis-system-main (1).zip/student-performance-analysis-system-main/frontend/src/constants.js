export const ROLES = {
  STUDENT: "STUDENT",
  TUTOR: "TUTOR",
  PRINCIPAL: "PRINCIPAL",
};
