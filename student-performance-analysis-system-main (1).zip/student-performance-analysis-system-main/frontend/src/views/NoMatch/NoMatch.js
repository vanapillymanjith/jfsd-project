function NoMatch() {
  return <h1>404 PAGE NOT FOUND</h1>;
}

export default NoMatch;
