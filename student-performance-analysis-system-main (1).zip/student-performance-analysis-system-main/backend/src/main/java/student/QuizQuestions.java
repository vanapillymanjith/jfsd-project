package student;

public class QuizQuestions{
    String question;
    String id;
    String options;

    public QuizQuestions(String id,String question, String options) {
        this.id = id;
        this.question = question;
        this.options = options;
    }

}
