package student;

public class Mark {
    int semester;
    int marks;
    String subjectId;
    String subjectName;

    public Mark(int semester, int marks, String subjectId, String subjectName) {
        this.semester = semester;
        this.marks = marks;
        this.subjectId = subjectId;
        this.subjectName = subjectName;
    }
}
