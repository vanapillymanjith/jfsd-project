package student;

public class Performance {
    int marks;
    int attendance;
    int quiz;

    public Performance(int marks, int attendance, int quiz) {
        this.marks = marks;
        this.attendance = attendance;
        this.quiz = quiz;
    }

}
