package auth;

public enum Roles {
    STUDENT,
    TUTOR,
    PRINCIPAL
}
