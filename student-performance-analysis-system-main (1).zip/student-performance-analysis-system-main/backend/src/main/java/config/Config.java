package config;

public class Config {
    public static final String DB_URL = "jdbc:mysql://@localhost:3306/miniproject";
    public static final String USER = "root";
    public static final String PASSWORD = "sree";
}
