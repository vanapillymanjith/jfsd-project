## Student Performance Analysis System
 
&emsp; &emsp;  The Students Performance Analysis System is a web application that is designed to maintain and manage the grades and attendance of students in all departments in a college. It also conducts performance evaluations in educational institutions. This system is essential for every educational institution as it reduces manpower. This system creates graphs automatically based on the marks secured by students.This system can be used by Student, Tutor and Principal. They need to login this system using their own login credentials. 
   
   
📌 Students can view view their own details, marks, attendance and also they need to take a Quiz weekly once.<br />
📌 Tutor can view their details and their student details including marks, attendance and their performance are represented through graphs.<br />
📌 Principal can view all the students and tutor details.<br />

   
   Tutor can add, modify, and delete information about their students. It also allows the student to see their individual performance throughout the semester. All the data is centralized. If a change is made to the data, then everyone who is using this application can see it.
   
   
- Frontend		:        React js, CSS
- Backend		  :        Java (Servlets)
- Database    :        Mysql
- Developmental tools : Visual Studio Code, IntelliJ
